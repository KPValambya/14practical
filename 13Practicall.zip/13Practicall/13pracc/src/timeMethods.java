import java.lang.Math.*;
import java.io.*;
import java.text.*;
import java.util.Random;

public class timeMethods {

    public static int N = 32654;   // given the key range from zero to 32654
    static int[] array = new int[N]; // for all the natural numbers (0-32654)

    public static void main(String args[]){

        DecimalFormat twoD = new DecimalFormat("0.00");
        DecimalFormat fourD = new DecimalFormat("0.0000");
        DecimalFormat fiveD = new DecimalFormat("0.00000");

        long start, finish;
        double runTimeLinear = 0, runTimeLinear2 = 0;
        double runTimeBinary = 0, runTimeBinary2 = 0;
        double time;

        int n = N;
        int repetition, repetitions = 30;

        Random rand = new Random();

// an array
        for(int i = 0; i < N; i++)
            array[i] = i + 1;

//this is for the linear search
        for(repetition = 0; repetition < repetitions; repetition++) {

            int key = rand.nextInt(N) + 1;

            start = System.currentTimeMillis();
            linearsearch(key);
            finish = System.currentTimeMillis();

            time = (double)(finish - start);
            runTimeLinear += time;
            runTimeLinear2 += (time*time);
        }

        double aveLinear = runTimeLinear/repetitions;
        double stdLinear =
                Math.sqrt(runTimeLinear2 - repetitions*aveLinear*aveLinear)
                        /(repetitions-1);


//this is for the binary search
        for(repetition = 0; repetition < repetitions; repetition++) {

            int key = rand.nextInt(N) + 1;

            start = System.currentTimeMillis();
            binarysearch(key);
            finish = System.currentTimeMillis();

            time = (double)(finish - start);
            runTimeBinary += time;
            runTimeBinary2 += (time*time);
        }

        double aveBinary = runTimeBinary/repetitions;
        double stdBinary =
                Math.sqrt(runTimeBinary2 - repetitions*aveBinary*aveBinary)
                        /(repetitions-1);


// the output results
        System.out.println("\nStatistics");
        System.out.println("________________________________________");

        System.out.println("Linear Average Time = "
                + fiveD.format(aveLinear) + " ms");
        System.out.println("Linear Std Dev      = "
                + fourD.format(stdLinear));

        System.out.println();

        System.out.println("Binary Average Time = "
                + fiveD.format(aveBinary) + " ms");
        System.out.println("Binary Std Dev      = "
                + fourD.format(stdBinary));

        System.out.println("________________________________________");
    }

    static int linearsearch(int key) {

        for(int i = 0; i < N; i++)
            if(array[i] == key)
                return i;

        return -1;
    }

    static int binarysearch(int key) {

        int low = 0;
        int high = N - 1;

        while(low <= high) {
            int mid = (low + high) / 2;

            if(array[mid] == key)
                return mid;
            else if(array[mid] < key)
                low = mid + 1;
            else
                high = mid - 1;
        }

        return -1;
    }
}